package com.entities.test;

public class EntitiesTest {

}
