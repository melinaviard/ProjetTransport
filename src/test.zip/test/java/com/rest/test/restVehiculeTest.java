package com.rest.test;

public class restVehiculeTest {

}
