package com.service.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.SpringBootRunner;
import com.adaming.dao.IClientRepository;
import com.adaming.model.Client;
import com.adaming.service.ClientServiceImpl;




@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootRunner.class)
public class ServiceClientTest {
	private ClientServiceImpl clientService;
	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceClientTest.class);

	//Creer faux repository 
	@Mock
	private IClientRepository clientRepository;
	
	// Initier mock avant d'effectuer le test
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		clientService = new ClientServiceImpl(clientRepository);
	}

	// Test que methodes dao sont bien appelées par ce service là
	@Test
	public void should_store_when_save_is_called() { 
		LOGGER.info("--------------- Executing should_store_when_save_is_called test Of ClientServiceTest ---------------");
		Client myClient = new Client();
		clientService.save(myClient);
		Mockito.verify(clientRepository).save(myClient); // pour tracker l'objet
	}
	
	@Test
	public void should_update_when_update_is_called() {
		LOGGER.info("--------------- Executing should_update_when_update_is_called test Of UserServiceImplTest ---------------");
		Client myClient = new Client();
		clientService.update(myClient);
		Mockito.verify(clientRepository).save(myClient);
	}
	
	
}
